// import { createSlice } from "@reduxjs/toolkit";

// export const formReducer = createSlice({
//   name: "form",
//   initialState: { userDetails: [] },
//   reducers: {
//     userReg: (state, action) => {

//     },
//     userLogin: (state, action) => {},
//   },
// });

// const { actions, reducer } = formReducer;
// export const { userReg, userLogin } = actions;
// export default reducer;
